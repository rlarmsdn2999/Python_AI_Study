import os
import numpy as np
import tensorflow as tf
import cv2
from keras import models
import winsound
import time
from imutils.video import WebcamVideoStream  # Webcam영상 스트림을 위해 import
# py -m pip install imutils

testPath = r'C:\Users\User\Desktop\RPS Game\datasets\test'
inputShape = (50, 50, 3)
numClass = 4  # 난초, 이삭, 쌍피, 장미, 빨삭, 불량

# 이미지 읽기 함수
def read_image(path):
    gfile = tf.io.read_file(path)
    image = tf.io.decode_image(gfile, dtype=tf.float32)
    return image

# 모델 불러오기
model = models.load_model('my_model.h5')

# Webcam을 host로 하여 ip어드레스와 port:4747지정
# DroidCam App상에 표시된 IP주소와 포트번호를 입력 
host = "{}:4747/video".format("http://192.168.0.43") 
capture= WebcamVideoStream(src=host).start()    # 비디오 스트림 시작. capture = cv2.VideoCapture(0) 부분에 해당

# 검출 간격 설정
detection_interval = 5  # 2초에 한 번 검출

last_detection_time = time.time()

while True:
    ret, frame = capture.read()
    if ret == True:
        cv2.imshow("VideoFrame", frame)
        keyInput = cv2.waitKey(20)

        # 현재 시간을 가져옴
        current_time = time.time()

        # 검출 간격마다 검출 수행
        if current_time - last_detection_time >= detection_interval:
            save = cv2.imwrite(testPath + "/1.jpg", frame, params=None)
            img = read_image(testPath + "/1.jpg")
            img = tf.image.resize(img, inputShape[:2])

            image = np.array(img)

            testImage = image[tf.newaxis, ...]
            pred = model.predict(testImage)
            num = np.argmax(pred)

            if num == 0:
                print("현관입니다.")
                
            elif num == 1:
                print("계단입니다.")
                
            elif num == 2:
                print("교실입니다.")
                
            elif num == 3:
                print("쉼터입니다.")
                
            last_detection_time = current_time  # 마지막 검출 시간 업데이트

        if keyInput == ord('q'):
            capture.release()
            cv2.destroyAllWindows()
            break

    else:
         break


